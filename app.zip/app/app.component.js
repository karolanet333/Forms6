"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'Caro';
        this.switch = true;
    }
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            template: "<h1>Hello {{name}}</h1> \n            <!--\n              <basic-http></basic-http>\n              <log-component></log-component>\n              <data-component></data-component>\n              <data-component-composed></data-component-composed>\n              <div [highlight]=\"'yellow'\" [defaultColor]=\"'red'\">Highlighted Text</div>\n              <hr>\n              <div>Unless Directive</div>\n              <button (click)=\"switch=!switch\">click to work with UnlessDirective</button>\n              <p>Variable: {{switch}}</p>\n              <p *unless=\"switch\">unless directive</p>\n            -->\n            <hr>\n            <a [routerLink]=\"['']\" [queryParams]=\"{analytics: 500}\" [fragment]=\"'section1'\" routerLinkActive=\"active\" >Home</a> |\n            <input type=\"text\" #id (input)=\"0\">\n            <a [routerLink]=\"['/user', id.value]\" [preserveQueryParams]=\"true\" routerLinkActive=\"active\" >User</a>\n            <hr>\n            <router-outlet></router-outlet>\n            ",
            styles: ["\n      .active{\n        color:red;\n      }\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map