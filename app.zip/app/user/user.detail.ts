import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'user-detail',
    template:
        `
            <h2>User Detail Component</h2>
        `
})
export class UserDetailComponent{

}